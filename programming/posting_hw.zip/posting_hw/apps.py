from django.apps import AppConfig


class PostingHwConfig(AppConfig):
    name = 'posting_hw'
